﻿#pragma once

// 画面のサイズ
const int kWindowWidth = 1280;
const int kWindowHeight = 720;

